<?php
    
    if(isset($_COOKIE['Login']))
    {  //判断客户端的cookie文件是否存在,存在的话将其设置为过期.
        setCookie('username', "", time()-0, "/"); 
        setCookie('email', "", time()-0, "/"); 
        setCookie('password', "", time()-0, "/"); 
        setCookie('sex', "", time()-0, "/"); 
        setCookie('Login', "", time()-0, "/"); 
        setCookie('member_id', "", time()-0, "/"); 
        setCookie('squence', "", time()-0, "/"); 
        setCookie('branch_id', "", time(), "/");
        setCookie('customer_num', "", time(), "/");  
    }
    header("Location: /DB_finnal/main_page/before.php");
?>