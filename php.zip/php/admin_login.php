
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>管理員登錄</title>

</head>
<body>
	<EMBED src="image/背景音乐.mp3"autostart="true" loop="true" hidden="true"> 
  <div class="A">
	  <div class="M">
			<form name="form1" method="post" action="logincheck.php">
				<h2>歡 迎 光 臨</h2>
				<font color="#FF0000">請輸入用戶:</font> 
				<input name="username" type="text" id="username" placeholder="Username"><br>
				<font color="#FF0000">請輸入密碼:</font>
				<input name="password" type="password" id="password" placeholder="Password"><br>
				<input name="submit" type="submit" value="確定登錄" style='font-size:20px'><br>
			</form>

			<form name="form2" method="post" action="reg.php">
				<br>還沒有帳號？
				<input name="reg" type="submit" value="點此註冊" >
			</form>
			<br>
	</div>
</div>
</body>
</html>