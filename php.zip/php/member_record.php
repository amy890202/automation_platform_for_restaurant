<?php
$servername = "localhost"; //伺服器連線名
$username = "root"; //資料庫使用者名稱
$password = ""; //資料庫密碼
$dbname = "eat_go"; //資料庫名
$conn = new mysqli($servername, $username, $password, $dbname); //連線資料庫
if (!$conn) {
	die("連線失敗：" . mysqli_connect_error()); //連線資料庫失敗則殺死程序
}

$username=$_COOKIE['username'];
$sql = "SELECT  ff_branch_id,f_service_id,price,payoff,start_time FROM orders,member WHERE f_member_id=member_id AND username='$username'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$total_money=ceil($row['price']*$row['payoff']);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["ff_branch_id"]. " - price: " . $row["price"]."<br>";
    }
} else {
    echo "0 results";
}
 /*   
echo "您好，".$username;
if(mysqli_num_rows($result)==0)
{
    echo "您沒有用餐紀錄";
}
else
{
    echo "您的用餐紀錄為: 在分店".$row['ff_branch_id']."享用套餐".$row['f_service_id']."<br>";
    echo "日期:".$row['start_time']."消費總金額:".$total_money;
}*/

?>