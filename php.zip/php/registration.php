<div class="container">
    <form id="form" class="signin" method="get"  action="member_regcheck.php">   
    <h1 class="header">REGISTRATION</h1>
    <label>
        <p class="label"><b>請輸入EMAIL:</b></p>
        <input 
          id="email" 
          name="reg_email" 
          type="text" 
          class="input" 
          required=""
          placeholder="Email"
        >
    </label>
    <label>
        <p class="label"><b>請輸入帳號:</b></p>
        <input 
          id="username"
          name="reg_username"
          type="text" 
          class="input" 
          required=""
          placeholder="Username"
        >
    </label>
    <label>
        <p class="label"><b>請輸入密碼:</b></p>
        <input 
          id="password" 
          name="reg_password"
          type="password" 
          class="input" 
          required=""
          placeholder="Password"
        >
    </label>
    <label>
        <p class="label"><b>請確認密碼:</b></p>
        <input 
          id="repassword"
          name="reg_repassword" 
          type="password" 
          class="input" 
          required=""
          placeholder="Comfirm password"
        >
    </label>
    

    <button 
		class="bu"  
        name="reg_submit" 
		value="registration" 
		type="submit"
    >
    <b>註冊</b></button>

    <div class='square'>
    </div>
    <img class='image' src="http://localhost/hw_login/image/computer.png" width="60" height="60">
</div>
<div class='gender'>
        <input type="radio"  checked="checked" name="reg_sex" value="male"/>男
        <input type="radio"  name="reg_sex" value="female"/>女
    <div>

<style> 
    .gender
    {
        position:relative;
        top:400px;
        left:-335px;
        
    }
    .square
    {
        width:400;
        height:30;
        background-color:black;
        position:relative;
        top:-375;
        left:20;
    }
    .image
    {
        position:relative;
        top:-430;
        left:-7;
    }

    .label
    {
        position:relative;
        top:20;
        left:-10;
        color:black;
        font-family:"微軟正黑體";
    }
    .input
    {
        position:relative;
        top:-16;
        left:100;
        width:300;
    }
    .header
    {
        text-align:center;
        margin-top: -50px;
        color: 	white;
        font-size: 36px;
        font-family:sans-serif;
        position:relative;
        z-index:100;
    }
    .container
    {
        display: flex;
        width: 500px;
        background-color: #FFA500;
        padding: 50px;
        position: relative;
    }
    body
    {
        padding: 60px;
        display: flex;
        justify-content: center;
        height: 520px;
        background-color:black;
        color: rgba(255,255,255,0.95);
    }
    .bu
    {
        position: relative;
        height: auto;
        width:300;
        top:65;
        left:60;
        padding: 10px;
        font-family:"微軟正黑體";
        cursor: pointer;
    }
    
    .signin 
    {
        max-width: 420px;
        padding: 30px 38px 66px;
        margin: 0 auto;
        background-color:#FFA500;
    }
</style>