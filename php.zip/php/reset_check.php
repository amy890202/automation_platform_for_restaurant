<?php
//連線資料庫並讀取資料表
$servername = "localhost"; //伺服器連線名
$username = "root"; //資料庫使用者名稱
$password = ""; //資料庫密碼
$dbname = "eat_go"; //資料庫名
$conn = new mysqli($servername, $username, $password, $dbname); //連線資料庫
echo "<table border='2' bordercolor='#66ccff'>";
if (!$conn) {
	die("連線失敗：" . mysqli_connect_error()); //連線資料庫失敗則殺死程序
}

if (isset($_GET['submit'])){
  $query = [
    'password' => htmlspecialchars($_GET["password"]),
    'pass' => htmlspecialchars($_GET["new_password1"]),
    'pass1'=> htmlspecialchars($_GET["new_password2"])
  ];
  echo $query['pass1'];
  if(strcasecmp($query['pass'],$query['pass1'])== 0)
    checkData($query['password'], $query['pass'],$conn);
  else
  {
    ?>
    <script type="text/javascript"> 
      alert("兩次密碼輸入不一致"); 
      window.location.href="reset_password.php";  
    </script>
    <?php 
  }
  
}

function checkData($password, $pass,$conn) {
  
    $username=$_COOKIE['username'];
    $password=md5($password, false);
    $sql = "SELECT member_id FROM member WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0) { 
      ?>
      <script type="text/javascript"> 
        alert("使用者帳號或密碼錯誤"); 
        window.location.href="http://localhost/DB_finnal/member_center/changepassword.php";  
      </script>
      <?php  
    } else {
      $pass=md5($pass, false);
      mysqli_query($conn,"UPDATE member SET password='$pass' WHERE username = '$username'");
      ?>
        <script type="text/javascript"> 
        alert("更改成功"); 
        window.location.href="login.php";  
        </script>
        <?php
    }
  }
$conn->close();
?>