<?php
header("Content-type:text/html;charset=utf-8");
$servername = "localhost"; //伺服器連線名
$username = "root"; //資料庫使用者名稱
$password = ""; //資料庫密碼
$dbname = "eat_go"; //資料庫名
$conn = new mysqli($servername, $username, $password, $dbname); //連線資料庫
if (!$conn) {
	die("連線失敗：" . mysqli_connect_error()); //連線資料庫失敗則殺死程序
}
if (isset($_GET['log_submit']))
{
  $query = [
    'email' => $_GET["log_email"],
    'password' => $_GET["log_password"]
  ];
  checkData($query['email'], md5($query['password'], false), $conn);
}
function checkData($email, $password, $conn) 
{
  $sql = "SELECT  username,email,password,sex,member_id FROM member WHERE email = '$email' AND password = '$password'";
  $result = mysqli_query($conn, $sql);
  if(mysqli_num_rows($result) == 0) 
    echo "<script> alert('用戶名或密碼錯誤');
          parent.location.href='/DB_finnal/login.php?error=用戶名或密碼錯誤'; </script>";
    //就因為中文；和英文;浪費我一小時 。。。。。。。。。。。
  else 
  {
    $row = mysqli_fetch_assoc($result);
    $time = time()+24*60*60;    
    setCookie('username', $row['username'], $time, "/"); 
    setCookie('email', $row['email'], $time, "/"); 
    setCookie('password', $row['password'], $time, "/"); 
    setCookie('sex', $row['sex'], $time, "/"); 
    setCookie('Login', 1, $time, "/"); 
    setCookie('member_id', $row['member_id'], $time, "/"); 
     echo "<script> alert('登入成功，歡迎光臨');
          parent.location.href='/DB_finnal/main_page/after.php'; </script>";
  }
}
$conn->close();
?>
