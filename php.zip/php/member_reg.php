<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>註冊新帳號</title>

  
</head>
<body>
  <div class="M"> 
  <form name="reg_form" method="post" action="member_regcheck.php">
    <h2>註 冊 帳 號</h2>
    輸入郵箱:
    <input name="reg_email" type="email" ><br>
    設置暱稱:
    <input name="reg_username" type="text" ><br>
    設置密碼:
    <input name="reg_password" type="password" ><br>
    重複密碼:
    <input name="reg_repassword" type="password" ><br>
    請選擇您的性別:
    <input type="radio" checked="checked" name="reg_sex" value="m"/>男
    <input type="radio"  name="reg_sex" value="f"/>女
    <br><br>
    <input name="reg_submit" type="submit" value="確定註冊" style='font-size:15px' >
  </form>
  <br>
</div>
</body>
</html>

 