<?php
header("Content-type:text/html;charset=utf-8");
$servername = "localhost";
$username = "root";
$password = "";
$database="eat_go";
$conn = new mysqli($servername, $username, $password,$database);

if (!$conn) 
{
  die("Connection failed: " . mysql_connect_error());
}


if (isset($_GET['reg_submit']))
{
  $query = [
   'email'=>$_GET["reg_email"],
    'username'=>$_GET["reg_username"],
    'password' => $_GET["reg_password"],
    'repassword'=>$_GET["reg_repassword"],
    'sex'=>$_GET["reg_sex"]
  ];
  if( $query['password']!= $query['repassword'])
    echo "<script> alert('兩次輸入密碼不一致');
          parent.location.href='/DB_finnal/member_reg.php'; </script>";
  insertData($query['email'],$query['username'], $query['password'],  $query['sex'],$conn);
}

function insertData($email,$username ,$password, $sex,$conn) 
{
  $sql = "SELECT member_id FROM member WHERE email = '$email'";
  $email_result = mysqli_query($conn, $sql);
  if(mysqli_num_rows($email_result) > 0) {
    echo "<script> alert('該email已註冊過');
          parent.location.href='/DB_finnal/registration.php'; </script>";
  }  
  else{
   $password=md5($password, false);
   $sql = "INSERT INTO member (email,username , password,sex,level,points)VALUES ('$email','$username','$password','$sex','VIP I',0)";
    if (mysqli_query($conn, $sql)) 
    {
      echo "<script> alert('您已成功註冊帳號');
          parent.location.href='/DB_finnal/login.php'; </script>";
    } 
    else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }  

  }
}