<div class="container">
        
        <form id="form" class="signin" method="get"  action="member_logcheck.php">   
        <h1 class="header">Login</h1>
		<input
			id="log_email"
			name="log_email" 
			type="email" 
			class="word" 
			placeholder="Email" 
            required=""
        >
		<input
			id="log_password"
			name="log_password"  
			type="password" 
			class="word" 
			placeholder="Password" 
            required=""
		>     		  
		<button 
			class="bu"  
            name="log_submit" 
			value="Login" 
			type="submit"
        >
        <b>登入</b></button> 

        <input type ="button" class="bu1" onclick="javascript:location.href='http://localhost/DB_finnal/registration.php'" value="註冊帳號"></input>

        <div class='square'>
        </div>
        <img class='image' src="http://localhost/hw_login/image/fingerprint .png" width="60" height="60">
</div>


<script> 

</script>

<style> 
    .square
    {
        width:300;
        height:30;
        background-color:black;
        position:relative;
        top:-230;
        left:10;
    }
    .image
    {
        position:relative;
        top:-290;
        left:30;
    }

    .header
    {
        text-align:center;
        margin-top: -50px;
        color: 	white;
        font-size: 36px;
        font-family:sans-serif;
        position:relative;
        z-index:100;
    }
    .container
    {
        display: flex;
        width: 400px;
        background-color:#FFA500;
        padding: 50px;
        position: relative;
    }
    body
    {
        padding: 60px;
        display: flex;
        justify-content: center;
        height: 400px;
        background-color:black;
        color: rgba(255,255,255,0.95);
        
    }
    .word
    {
        position: relative;
        top:20;
        left:10;
        font-size: 16px;
        height: 50;
        width: 300;
        padding: 10px;
    }
    .bu
    {
        position: relative;
        height: auto;
        width:300;
        top:45;
        left:10;
        padding: 10px;
        font-family:"微軟正黑體";
        cursor: pointer;
    }
    .bu1
    {
        position: relative;
        height: auto;
        width:300;
        top:50;
        left:10;
        padding: 10px;
        font-family:"微軟正黑體";
        border:0px;
        text-decoration:underline;
        cursor: pointer;
        background-color:#FFA500;
    }
    .signin 
    {
        max-width: 420px;
        padding: 30px 38px 66px;
        margin: 0 auto;
        background-color: #FFA500;
    }
</style>